public class Commands{
    private final String beginOutput = "\n" + "----------" + "\n";
    private final String endOutput = "\n" + "----------" + "\n" + "\n";

    public void askForCommands(windowlayout a){
        if(a.playerStringForObjects.equalsIgnoreCase("commands")){
            a.textArea.append(beginOutput + "  get X - get an object, usually capitalized. Some can't" + "\n" + "  be obtained though." + "\n" + "\n" + "  go X - goes to different places. You can go" + "\n" + "  NORTH, SOUTH, EAST, or WEST." + "\n" + "\n" + "  use X - uses an item you already have. Won't" + "\n" + "  work if not in the right area. " + "\n" + "\n" + "  Special Cases - if a statement ends in a pair" + "\n" + "  of () with capitalized text inside, you can respond using" + "\n" + "  those texts, which are separated by a /" + endOutput);
            a.playerStringForObjects = "";
        }
    }

    
    //obligatory tostring method frfr
    public String toString(){
        return "GRAHHH";
    }
    //obligatory round integer method frfr
    public int roundInt(int a){
        return (int)(a + .5);
    }
}